%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *s);
int yylex(void);

#define SIZE 101

struct Elemento {
    char *val;
    int count;
    struct Elemento *sig;
};

struct Elemento *tabla[SIZE];

unsigned generar_hash(char *s) {
    unsigned h = 0;
    while (*s)
        h = 31 * h + (*s++ | 32);
    return h % SIZE;
}

void registrar(char *s) {
    unsigned h = generar_hash(s);
    struct Elemento *e = tabla[h];

    while (e) {
        if (strcasecmp(s, e->val) == 0) {
            e->count++;
            return;
        }
        e = e->sig;
    }

    struct Elemento *nuevo = malloc(sizeof(struct Elemento));
    nuevo->val = strdup(s);
    nuevo->count = 1;
    nuevo->sig = tabla[h];
    tabla[h] = nuevo;
}
%}

%union {
    char *str;
}

%token <str> WORD

%%

entrada:
      /* vacío */
    | entrada WORD { registrar($2); }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main() {
    yyparse();

    for (int i = 0; i < SIZE; i++) {
        struct Elemento *e = tabla[i];
        while (e) {
            printf("%s %d\n", e->val, e->count);
            e = e->sig;
        }
    }

    return 0;
}
