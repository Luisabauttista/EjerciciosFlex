%{
#include <stdio.h>
#include <stdlib.h>

void yyerror(const char *s);
int yylex(void);
%}

%union {
    int num;
}

%token <num> NUM

%left '+' '-'
%left '*' '/'

%type <num> expr

%%

entrada:
      /* vacío */
    | entrada expr '\n' { printf("Resultado: %d\n", $2); }
    ;

expr:
      NUM               { $$ = $1; }
    | expr '+' expr     { $$ = $1 + $3; }
    | expr '-' expr     { $$ = $1 - $3; }
    | expr '*' expr     { $$ = $1 * $3; }
    | expr '/' expr     { $$ = $1 / $3; }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int main() {
    printf("Ingrese operaciones:\n");
    yyparse();
    return 0;
}
